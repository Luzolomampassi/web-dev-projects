
<?php
// SMTP settings belong in environment variables or a local, untracked .env file.
